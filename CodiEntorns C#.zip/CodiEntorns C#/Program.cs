﻿using System;

class Program
{
    static void Main()
    {
        string dni;

        do
        {
            Console.WriteLine("Introdueix el número de DNI (8 números, sense lletra): ");
            dni = Console.ReadLine();

            if (dni.Length != 8)
            {
                Console.WriteLine("el DNI ha de tenir obligatoriament 8 números.");
            }
            else if (!EsNumeric(dni))
            {
                Console.WriteLine("Nomes es permeten numeros");
            }

        } while (dni.Length != 8 || !EsNumeric(dni));

        int numero = int.Parse(dni);

        string lletres = "TRWAGMYFPDXBNJZSQVHLCKE";
        int residu = numero % 23;
        char lletra = lletres[residu];

        Console.WriteLine("La lletra del DNI és: " + lletra);
    }

    static bool EsNumeric(string text)
    {
        for (int i = 0; i < text.Length; i++)
        {
            if (!char.IsDigit(text[i]))
                return false;
        }
        return true;
    }
}