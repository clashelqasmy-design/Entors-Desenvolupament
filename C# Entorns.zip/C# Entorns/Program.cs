﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdueix el número de DNI (sense lletra): ");
        string dni = Console.ReadLine();

        int suma = 0;

        for (int i = 0; i < dni.Length; i++)
        {
            suma += int.Parse(dni[i].ToString());
        }

        Console.WriteLine("La suma de les xifres és: " + suma);
    }
}